<?php
class ControllerExtensionModule3xGen extends Controller {

    private $error = array();
	
	public function install(){
	
		$this->load->model('extension/module/3x_gen');
		$this->model_extension_module_3x_gen->start();
	}
		
	public function uninstall(){
	
		$this->load->model('extension/module/3x_gen');
		$this->model_extension_module_3x_gen->finish();
	}
		
    public function index(){
		
		$this->language->load('extension/module/3x_gen');
				
        $this->document->setTitle($this->language->get('heading_title'));
		
		$this->document->addScript('view/javascript/3x_gen.js');
        
        $this->load->model('setting/setting');
		
		$this->load->model('extension/module/3x_gen');
		
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()){
			$this->model_setting_setting->editSetting('module_3x_gen', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		if (isset($this->error['warning'])){
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/3x_gen', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/3x_gen', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		if (isset($this->request->post['module_3x_gen_status'])){
			$data['module_3x_gen_status'] = $this->request->post['module_3x_gen_status'];
		} else {
			$data['module_3x_gen_status'] = $this->config->get('module_3x_gen_status');
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/3x_gen', $data)); 
	}
  
	public function getmask(){
		
		$this->load->model('extension/module/3x_gen');
		
		if(isset($_POST['varmask']) && isset($_POST['lg'])){
			
            $varmask 	= $_POST['varmask'];
			$lg 		= $_POST['lg'];
            $result 	= $this->model_extension_module_3x_gen->getmask($varmask, $lg);
			
			if ($result != "lost"){
				$data['sqlmask'] = $result->row["maska"];
			} else {
				$data['sqlmask'] = "";
			}
			
			$response = json_encode($data);
            echo $response;
		}
	}
	
	public function putmask(){
		
		$this->load->model('extension/module/3x_gen');
		
		if(isset($_POST['putmask']) && isset($_POST['lg']) && isset($_POST['savemask'])){
			
            $putmask 	= $_POST['putmask'];
			$lg 		= $_POST['lg'];
			$savemask 	= $_POST['savemask'];
            			
			$this->model_extension_module_3x_gen->putmask($putmask, $lg, $savemask);
			
            echo "success";
		}
	}

    public function generate(){

        if (isset($_POST['id_1']) && isset($_POST['id_2']) && isset($_POST['lg']) && isset($_POST['savemask']) && isset($_POST['rewrite'])){

			$id_1  		= $_POST['id_1'];
            $id_2  		= $_POST['id_2'];
            $savemask 	= $_POST['savemask'];
            $rewrite  	= $_POST['rewrite'];
			$lg 	  	= $_POST['lg'];

            $this->load->model('extension/module/3x_gen');
            $arr_mask = explode("-", $savemask); 
			
            $store = $this->model_extension_module_3x_gen->get_store_id();
            $store_id = array();
            $store_id[0] = "0";

            if ($store->num_rows != 0) {
                $k = 1;
                foreach ($store->rows as $sid){
                    $store_id[$k] = $sid[key($sid)];
                    $k++;
                }
            }
            
			switch ($id_1){
				case 1: $this->gen_url($id_2, $arr_mask, $rewrite, $lg, $store_id); break;
				case 2: $this->gen_h1($id_2, $arr_mask, $rewrite, $lg); break;
				case 3: $this->gen_title($id_2, $arr_mask, $rewrite, $lg); break;
				case 4: $this->gen_keywords($id_2, $arr_mask, $rewrite, $lg); break;
				case 5: $this->gen_description($id_2, $arr_mask, $rewrite, $lg); break;
			}
		}
		
        echo json_encode("success");
    }

    private function gen_url($id_2, $arr_mask, $rewrite, $lg, $store_id){
		
		$this->load->model('extension/module/3x_gen');
		$pro_id = $this->model_extension_module_3x_gen->get_all($id_2);
        $trans_url = "";  
				
        foreach ($store_id as $sid){
			foreach ($pro_id->rows as $pid){
				foreach ($arr_mask as $part_mask){
					if ($id_2 == 6){
						switch ($part_mask){
							case "#p" : $query = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
							case "#m" : $query = "SELECT `model` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
							case "#a" : $query = "SELECT `sku` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
							case "#w" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` =(SELECT `manufacturer_id` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "')"; break;
							case "#l" : $query = "SELECT `code` FROM `" . DB_PREFIX . "language` WHERE `language_id` = '" . (int)$lg . "'"; break;
							case "#u" : $query = "SELECT `upc` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
						}
					} elseif ($id_2 == 7){
						switch ($part_mask){
							case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` ='" . (int)$pid[key($pid)]. "'"; break;
							case "#l" : $query = "SELECT `code` FROM `" . DB_PREFIX . "language` WHERE `language_id` = '" . (int)$lg . "'"; break;
						}
					} elseif ($id_2 == 8){
						switch ($part_mask){
							case "#w" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` ='" . (int)$pid[key($pid)]. "'"; break;
							case "#l" : $query = "SELECT `code` FROM `" . DB_PREFIX . "language` WHERE `language_id` = '" . (int)$lg . "'"; break;
						}
					} elseif ($id_2 == 9){
						switch ($part_mask){
							case "#i" : $query = "SELECT `title` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` ='" . (int)$pid[key($pid)]. "'"; break;
							case "#l" : $query = "SELECT `code` FROM `" . DB_PREFIX . "language` WHERE `language_id` = '" . (int)$lg . "'"; break;
						}
					}

					if(!empty($query)){
						
						$data_mask = $this->model_extension_module_3x_gen->get_datamask($query);
						$query = "";
																	
						foreach ($data_mask as $value){
							if ($part_mask =="#l" ){
								$value = substr($value,0,2);
							}
							$trans_url .= $value . " ";
						}
					} elseif (strpbrk($part_mask, '|')){
						
						$part_trim = ltrim($part_mask, "|");
						$arr_part = explode(";", $part_trim);
						$key_rnd = array_rand($arr_part, 1);
						$arr_rnd = $arr_part[$key_rnd];
						
						$trans_url .= $arr_rnd . " ";
					} else {
						$trans_url .= $part_mask . " ";
					}
				}

				if(!empty($trans_url)){
					$out_url = $this->convert($trans_url);
					$out = array ($sid, $lg, key($pid)."=".$pid[key($pid)], $out_url, $rewrite);
					$this->model_extension_module_3x_gen->write_url($out);
					$trans_url = "";
				}
			}
        }
		
		return 0;
	}
		
	private function gen_h1($id_2, $arr_mask, $rewrite, $lg){
		
		$this->load->model('extension/module/3x_gen');
		$pro_id = $this->model_extension_module_3x_gen->get_all($id_2);
		$h1 = "";
		
		foreach ($pro_id->rows as $pid){
			foreach ($arr_mask as $part_mask){
				if ($id_2 == 6){
					switch ($part_mask) {
						case "#p" : $query = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
					}
				} elseif ($id_2 == 7){
					switch ($part_mask) {
						case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
					}
				} elseif ($id_2 == 8){
					switch ($part_mask) {
						case "#m" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` = '" . (int)$pid[key($pid)]. "'"; break;
					}
				} elseif ($id_2 == 9){
					switch ($part_mask) {
						case "#i" : $query = "SELECT `title` AS `name` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
					}
				}
				
				if (!empty($query)){
					$data_mask = $this->model_extension_module_3x_gen->get_datamask($query);
					
					foreach ($data_mask as $value) {
						$h1 .= $value . " ";
					}
					$query = "";
				} elseif (strpbrk($part_mask, '|')){
					
					$part_trim = ltrim($part_mask, "|");
					$arr_part = explode(";", $part_trim);
					$key_rnd = array_rand($arr_part, 1);
					$arr_rnd = $arr_part[$key_rnd];
					
					$h1 .= $arr_rnd . " ";
				} else {
					$h1 .= $part_mask . " ";
				}
			}
			
			$h1 = trim($h1);
			$out = array ($lg, $pid[key($pid)], $h1, $rewrite, $id_2);
			$this->model_extension_module_3x_gen->write_h1($out);
			$h1 = "";
		}
		
		return 0;
	}
	
	private function gen_title($id_2, $arr_mask, $rewrite, $lg){
		
		$this->load->model('extension/module/3x_gen');
		$pro_id = $this->model_extension_module_3x_gen->get_all($id_2);
		$title = "";
		
		foreach ($pro_id->rows as $pid){
			foreach ($arr_mask as $part_mask){
				if ($id_2 == 6){
					switch ($part_mask){
						case "#p" : $query = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#z" : $query = "SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#g" : $query = "SELECT `name` FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '" . (int)$this->config->get('config_zone_id') . "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				} elseif ($id_2 == 7){
					switch ($part_mask){
						case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#g" : $query = "SELECT `name` FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '" . (int)$this->config->get('config_zone_id') . "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				} elseif ($id_2 == 8){
					switch ($part_mask){
						case "#m" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#g" : $query = "SELECT `name` FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '" . (int)$this->config->get('config_zone_id') . "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				} elseif ($id_2 == 9){
					switch ($part_mask){
						case "#i" : $query = "SELECT `title` AS `name` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				}
				
				if (!empty($query)){
					$data_mask = $this->model_extension_module_3x_gen->get_datamask($query);
											
					foreach ($data_mask as $value){
						if ($part_mask == "#z"){
							$value = round ($value, 0);
						}
						$title .= $value . " ";
					}
					$query = "";
				} elseif (strpbrk($part_mask, '|')){
					
					$part_trim = ltrim($part_mask, "|");
					$arr_part = explode(";", $part_trim);
					$key_rnd = array_rand($arr_part, 1);
					$arr_rnd = $arr_part[$key_rnd];
					
					$title .= $arr_rnd . " ";
				} else {
					$title .= $part_mask . " ";
				}
				$test ="";
			}
			
			$title = trim($title);
			$out = array ($lg, $pid[key($pid)], $title, $rewrite, $id_2);
			$this->model_extension_module_3x_gen->write_title($out);
			$title = "";
		}
		
		return 0;
	}
		
			
	private function gen_keywords($id_2, $arr_mask, $rewrite, $lg){
		
		$this->load->model('extension/module/3x_gen');
		$pro_id = $this->model_extension_module_3x_gen->get_all($id_2);
		$keywords = "";
		
		foreach ($pro_id->rows as $pid){
			foreach ($arr_mask as $part_mask){
				if ($id_2 == 6){
					switch ($part_mask){
						case "#p" : $query = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#z" : $query = "SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#m" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#a" : $query = "SELECT `sku` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
					}
				} elseif ($id_2 == 7){
					switch ($part_mask){
						case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
					}
				} elseif ($id_2 == 8){
					switch ($part_mask){
						case "#m" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` = '" . (int)$pid[key($pid)]. "'"; break;
					}
				} elseif ($id_2 == 9){
					switch ($part_mask){
						case "#i" : $query = "SELECT `title` AS `name` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
					}
				}
				
				if (!empty($query)){
					$data_mask = $this->model_extension_module_3x_gen->get_datamask($query);
											
					foreach ($data_mask as $value){
						if ($part_mask == "#z"){
							$value = round ($value, 0);
						}
						$keywords .= $value . ", ";
					}
					$query = "";
				} elseif (strpbrk($part_mask, '|')){
					
					$part_trim = ltrim($part_mask, "|");
					$arr_part = explode(";", $part_trim);
					$key_rnd = array_rand($arr_part, 1);
					$arr_rnd = $arr_part[$key_rnd];
					
					$keywords .= $arr_rnd . " ";
				} else {
					$keywords .= $part_mask . ", ";
				}
				$test ="";
			}
			
			$keywords = trim($keywords);
			$keywords = rtrim($keywords, ",");
			$keywords = strtolower($keywords);
			$out = array ($lg, $pid[key($pid)], $keywords, $rewrite, $id_2);
			$this->model_extension_module_3x_gen->write_keywords($out);
			$keywords = "";
		}
		
		return 0;
	}
	
	private function gen_description($id_2, $arr_mask, $rewrite, $lg){
		
		$this->load->model('extension/module/3x_gen');
		$pro_id = $this->model_extension_module_3x_gen->get_all($id_2);
		$description = "";
		
		foreach ($pro_id->rows as $pid){
			foreach ($arr_mask as $part_mask){
				if ($id_2 == 6){
					switch ($part_mask){
						case "#p" : $query = "SELECT `name` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#z" : $query = "SELECT `price` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#m" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#a" : $query = "SELECT `sku` FROM `" . DB_PREFIX . "product` WHERE `product_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				} elseif ($id_2 == 7){
					switch ($part_mask){
						case "#k" : $query = "SELECT `name` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				} elseif ($id_2 == 8){
					switch ($part_mask){
						case "#m" : $query = "SELECT `name` FROM `" . DB_PREFIX . "manufacturer` WHERE `manufacturer_id` = '" . (int)$pid[key($pid)]. "'"; break;
						case "#s" : $part_mask = $this->config->get('config_name'); break;
					}
				} elseif ($id_2 == 9){
					switch ($part_mask){
						case "#i" : $query = "SELECT `title` AS `name` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$pid[key($pid)]. "' AND `language_id` = '" . (int)$lg . "'"; break;
					}
				}
				
				if (!empty($query)){
					$data_mask = $this->model_extension_module_3x_gen->get_datamask($query);
											
					foreach ($data_mask as $value){
						if ($part_mask == "#z"){
							$value = round ($value, 0);
						}
						$description .= $value . " ";
					}
					$query = "";
				} elseif (strpbrk($part_mask, '|')){
					
					$part_trim = ltrim($part_mask, "|");
					$arr_part = explode(";", $part_trim);
					$key_rnd = array_rand($arr_part, 1);
					$arr_rnd = $arr_part[$key_rnd];
					
					$description .= $arr_rnd . " ";
				} else {
					$description .= $part_mask . " ";
				}
				$test ="";
			}
			
			$description = trim($description);
			$out = array ($lg, $pid[key($pid)], $description, $rewrite, $id_2);
			$this->model_extension_module_3x_gen->write_description($out);
			$description = "";
		}
		
		return 0;
	}
  
    public function convert($name){
		$list = array(
				'а' => 'a',   'б' => 'b',   'в' => 'v',
				'г' => 'g',   'д' => 'd',   'е' => 'e',
				'ё' => 'yo',  'ж' => 'zh',  'з' => 'z',
				'и' => 'i',   'й' => 'y',   'к' => 'k',
				'л' => 'l',   'м' => 'm',   'н' => 'n',
				'о' => 'o',   'п' => 'p',   'р' => 'r',
				'с' => 's',   'т' => 't',   'у' => 'u',
				'ф' => 'f',   'х' => 'h',   'ц' => 'c',
				'ч' => 'ch',  'ш' => 'sh',  'щ' => 'shch',
				'ь' => '',	  'ы' => 'y',   'ъ' => '',
				'э' => 'eh',  'ю' => 'yu',  'я' => 'ya',
				'ґ' => 'g',   'ї' => 'i',   'є' => 'e',		 
				'А' => 'A',   'Б' => 'B',   'В' => 'V',
				'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
				'Ё' => 'YO',  'Ж' => 'Zh',  'З' => 'Z',
				'И' => 'I',   'Й' => 'J',   'К' => 'K',
				'Л' => 'L',   'М' => 'M',   'Н' => 'N',
				'О' => 'O',   'П' => 'P',   'Р' => 'R',
				'С' => 'S',   'Т' => 'T',   'У' => 'U',
				'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
				'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Shch',
				'Ь' => '',    'Ы' => 'Y',   'Ъ' => '',
				'Э' => 'Eh',  'Ю' => 'Yu',  'Я' => 'Ya',
				'Ґ' => 'G',   'Ї' => 'I',   'Є' => 'E',
		);
		$url = htmlspecialchars_decode($name);
		$url = strtr($url, $list);
		$url = strtolower($url);
		$url = preg_replace('/[^-a-z0-9_]+/u', '-', $url);
		$url = trim($url, "-_");
		return $url;
	}
	
	protected function validate(){
		
		if (!$this->user->hasPermission('modify', 'extension/module/3x_gen')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}
}
?>