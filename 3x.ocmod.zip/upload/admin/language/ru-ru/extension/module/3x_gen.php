<?php
// Heading
$_['heading_title'] 	= '3.x Генератор';
$_['top_title']		 	= 'Генератор Free';

// Text
$_['text_module'] 		= 'Модули';
$_['text_edit'] 		= 'Настройки';
$_['text_extension']   	= 'Расширения';
$_['text_success']     	= 'Настройки успешно изменены!';
$_['text_url'] 	    	= 'Генерировать URL';
$_['text_h1'] 	    	= 'Генерировать H1';
$_['text_title']    	= 'Генерировать Title';
$_['text_keyword']    	= 'Генерировать Keyword';
$_['text_description'] 	= 'Генерировать Description';
$_['text_product']    	= 'Товары';
$_['text_category']    	= 'Категории';
$_['text_manufacturer']	= 'Производители';
$_['text_information'] 	= 'Статьи';
$_['text_rewrite']	 	= 'Перезаписывать существуюшие !!!';
$_['text_gener']	 	= 'ГЕНЕРИРОВАТЬ';
$_['text_mask']		 	= 'Ввести шаблон маски';

// Entry
$_['entry_status']     	= 'Статус';

// Error
$_['error_permission'] 	= 'У Вас нет прав для управления данным модулем!';
