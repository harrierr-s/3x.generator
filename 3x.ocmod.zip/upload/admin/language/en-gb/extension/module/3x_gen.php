<?php
// Heading
$_['heading_title'] 	= '3.x Generator';
$_['top_title']		 	= 'Generator Free';

// Text
$_['text_module'] 		= 'Modules';
$_['text_edit'] 		= 'Settings';
$_['text_extension']   	= 'Extensions';
$_['text_success']     	= 'Success: You have modified featured module!';
$_['text_url'] 	    	= 'Generate URL';
$_['text_h1'] 	    	= 'Generate H1';
$_['text_title']    	= 'Generate Title';
$_['text_keyword']    	= 'Generate Keyword';
$_['text_description'] 	= 'Generate Description';
$_['text_product']    	= 'Products';
$_['text_category']    	= 'Categories';
$_['text_manufacturer']	= 'Manufacturers';
$_['text_information'] 	= 'Informations';
$_['text_rewrite']	 	= 'Overwrite !!!';
$_['text_gener']	 	= 'GENERATE';
$_['text_mask']		 	= 'Enter template';

// Entry
$_['entry_status']     	= 'Status';

// Error
$_['error_permission'] 	= 'Warning: You do not have permission to modify featured module!';
