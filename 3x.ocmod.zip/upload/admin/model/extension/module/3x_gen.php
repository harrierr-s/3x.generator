<?php
class ModelExtensionModule3xGen extends Model {

	public function start() {
		
		$query = $this->db->query("DESC `" . DB_PREFIX . "product_description`");
		$fields = array();
		foreach ($query->rows as $row) {
			$fields[] = $row['Field'];
		}
		if (!in_array("meta_h1", $fields)) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "product_description` ADD `meta_h1` VARCHAR(255) NOT NULL AFTER `meta_keyword`");	
		}	
		
		$query = $this->db->query("DESC `" . DB_PREFIX . "category_description`");
		$fields = array();
		foreach ($query->rows as $row) {
			$fields[] = $row['Field'];
		}
		if (!in_array("meta_h1", $fields)) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "category_description` ADD `meta_h1` VARCHAR(255) NOT NULL AFTER `meta_keyword`");	
		}
		
		$query = $this->db->query("DESC `" . DB_PREFIX . "information_description`");
		$fields = array();
		foreach ($query->rows as $row) {
			$fields[] = $row['Field'];
		}
		if (!in_array("meta_h1", $fields)) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "information_description` ADD `meta_h1` VARCHAR(255) NOT NULL AFTER `meta_keyword`");	
		}
	
		$query = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "mask'");
		if ($query->num_rows == 0 ) {
			$this->db->query("CREATE TABLE `" . DB_PREFIX . "mask` (`maskod` INT(11) NOT NULL, `language_id` INT(11) NOT NULL, `maska` VARCHAR(512) NOT NULL, PRIMARY KEY (`maskod`, `language_id`)) ENGINE = MYISAM");
		} else {
			$this->db->query("DROP TABLE `" . DB_PREFIX . "mask`");
			$this->db->query("CREATE TABLE `" . DB_PREFIX . "mask` (`maskod` INT(11) NOT NULL, `language_id` INT(11) NOT NULL, `maska` VARCHAR(512) NOT NULL, PRIMARY KEY (`maskod`, `language_id`)) ENGINE = MYISAM");
		}
		
		$query = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "manufacturer_description'");
		if ($query->num_rows == 0 ) {
			$this->db->query("CREATE TABLE `" . DB_PREFIX . "manufacturer_description` (`manufacturer_id` INT(11) NOT NULL, `language_id` INT(11) NOT NULL, `description` MEDIUMTEXT NOT NULL, `meta_title` VARCHAR(255) NOT NULL, `meta_description` VARCHAR(255) NOT NULL, `meta_keyword` VARCHAR(255) NOT NULL, `meta_h1` VARCHAR(255) NOT NULL, PRIMARY KEY (`manufacturer_id`, `language_id`)) ENGINE = MYISAM");
		} else {
			$this->db->query("DROP TABLE `" . DB_PREFIX . "manufacturer_description`");
			$this->db->query("CREATE TABLE `" . DB_PREFIX . "manufacturer_description` (`manufacturer_id` INT(11) NOT NULL, `language_id` INT(11) NOT NULL, `description` MEDIUMTEXT NOT NULL, `meta_title` VARCHAR(255) NOT NULL, `meta_description` VARCHAR(255) NOT NULL, `meta_keyword` VARCHAR(255) NOT NULL, `meta_h1` VARCHAR(255) NOT NULL, PRIMARY KEY (`manufacturer_id`, `language_id`)) ENGINE = MYISAM");
		}
		return 0;
	}
	
	public function finish() {

		$query = $this->db->query("DESC `" . DB_PREFIX . "product_description`");
		$fields = array();
		foreach ($query->rows as $row) {
			$fields[] = $row['Field'];
		}
		if (in_array("meta_h1", $fields)) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "product_description` DROP COLUMN `meta_h1`");	
		}	
		
		$query = $this->db->query("DESC `" . DB_PREFIX . "category_description`");
		$fields = array();
		foreach ($query->rows as $row) {
			$fields[] = $row['Field'];
		}
		if (in_array("meta_h1", $fields)) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "category_description` DROP COLUMN `meta_h1`");	
		}
		
		$query = $this->db->query("DESC `" . DB_PREFIX . "information_description`");
		$fields = array();
		foreach ($query->rows as $row) {
			$fields[] = $row['Field'];
		}
		if (in_array("meta_h1", $fields)) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "information_description` DROP COLUMN `meta_h1`");	
		}
	
		$query = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "mask'");
		if ($query->num_rows != 0 ) {
			$this->db->query("DROP TABLE `" . DB_PREFIX . "mask`");
		}
		
		$query = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "manufacturer_description'");
		if ($query->num_rows != 0 ) {
			$this->db->query("DROP TABLE `" . DB_PREFIX . "manufacturer_description`");
		}
		return 0;
	}
	
	public function get_store_id() {		
		
		$query = "SELECT `store_id` FROM `" . DB_PREFIX . "store`";
		$store = $this->db->query($query);

		return $store ;
    }
	
	public function get_datamask($query) {
		
        $datamask = $this->db->query($query);

		return $datamask->row;
    }

    public function get_all($id_2) {
        
		switch ($id_2){
			case 6: $query = "SELECT `product_id` FROM `" . DB_PREFIX . "product`"; break;
			case 7: $query = "SELECT `category_id` FROM `" . DB_PREFIX . "category`"; break;
			case 8: $query = "SELECT `manufacturer_id` FROM `" . DB_PREFIX . "manufacturer`"; break;
			case 9: $query = "SELECT `information_id` FROM `" . DB_PREFIX . "information`"; break;
		}
		
		$data_out = $this->db->query($query);
		        
		return $data_out;
    }
	
	public function write_url($data) {
        
		$str_rand = '0123456789abcdefghijklmnopqrstuvwxyz';
		$test = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `store_id` = '" . (int)$data[0]. "' AND `language_id` = '" . (int)$data[1] . "' AND `query` = '" . $data[2] . "'");
		$duble = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `keyword` = '" . $data[3] . "' AND `seo_url_id` != '" . $test->rows[0]["seo_url_id"] . "'"); 
		
		while ($duble->num_rows != 0) {
			
			$data[3] = $data[3]."-".substr(str_shuffle($str_rand), 0, 3);
			$duble = $this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `keyword` = '" . $data[3] . "' AND `seo_url_id` != '" . $test->rows[0]["seo_url_id"] . "'");
		}

		if($test->num_rows != 0 ) {
			if($data[4] == "true" || empty($test->rows[0]["keyword"])) {
				$this->db->query("UPDATE `" . DB_PREFIX . "seo_url` SET `keyword` = '" . $data[3] . "' WHERE `store_id` = '" . (int)$data[0]. "' AND `language_id` = '" . (int)$data[1] . "' AND `query` = '" . $data[2] . "'");
			}
		} else {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` (`store_id`, `language_id`, `query`, `keyword`) VALUES ('" . $data[0] . "', '" . $data[1] . "', '" . $data[2] . "', '" . $data[3] . "')");
		}

		return 0;
    }
	
	public function write_h1($data) {
		
		switch ($data[4]){
			case 6 : $query = "SELECT `meta_h1` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 7 : $query = "SELECT `meta_h1` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 8 : $query = "SELECT `meta_h1` FROM `" . DB_PREFIX . "manufacturer_description` WHERE `manufacturer_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 9 : $query = "SELECT `meta_h1` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
		}
		
		$test = $this->db->query($query);
        
		if($test->num_rows != 0 ){
			foreach ($test->rows as $value) {
				if (empty($value["meta_h1"])) {
					if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_h1` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 7) {
						$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_h1` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 8) {
						$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_h1` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 9) {
						$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_h1` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					}
				} else {
					if ($data[3] == "true"){
						if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_h1` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 7) {
							$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_h1` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 8) {
							$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_h1` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 9) {
							$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_h1` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						}
					}
				}
			}
		} else {
			if ($data[4] == 6) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` (`product_id`, `language_id`, `meta_h1` ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 7) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_description` (`category_id`, `language_id`, `meta_h1`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 8) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "manufacturer_description` (`manufacturer_id`, `language_id`, `meta_h1`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 9) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "information_description` (`information_id`, `language_id`, `meta_h1`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			}
		}

		return 0;
    }
	
	public function write_title($data) {
		
		switch ($data[4]){
			case 6 : $query = "SELECT `meta_title` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 7 : $query = "SELECT `meta_title` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 8 : $query = "SELECT `meta_title` FROM `" . DB_PREFIX . "manufacturer_description` WHERE `manufacturer_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 9 : $query = "SELECT `meta_title` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
		}
		
		$test = $this->db->query($query);
        
		if ($test->num_rows != 0 ) {
			foreach ($test->rows as $value) {
				if (empty($value["meta_title"])) {
					if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_title` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 7) {
						$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_title` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 8) {
						$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_title` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 9) {
						$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_title` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					}
				} else {
					if ($data[3] == "true") {
						if ($data[4] == 6) {
							$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_title` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 7) {
							$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_title` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 8) {
							$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_title` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 9) {
							$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_title` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						}
					}
				}
			}
		} else {
			if ($data[4] == 6) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` (`product_id`, `language_id`, `meta_title` ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 7) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_description` (`category_id`, `language_id`, `meta_title`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 8) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "manufacturer_description` (`manufacturer_id`, `language_id`, `meta_title`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 9) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "information_description` (`information_id`, `language_id`, `meta_title`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			}
		}

		return 0;
    }
	
	public function write_keywords($data) {
		
		switch ($data[4]) {
			case 6 : $query = "SELECT `meta_keyword` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 7 : $query = "SELECT `meta_keyword` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 8 : $query = "SELECT `meta_keyword` FROM `" . DB_PREFIX . "manufacturer_description` WHERE `manufacturer_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 9 : $query = "SELECT `meta_keyword` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
		}
		
		$test = $this->db->query($query);
        
		if ($test->num_rows != 0 ) {
			foreach ($test->rows as $value) {
				if (empty($value["meta_keyword"])) {
					if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 7) {
						$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 8) {
						$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 9) {
						$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					}
				} else {
					if ($data[3] == "true") {
						if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 7) {
							$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 8) {
							$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 9) {
							$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_keyword` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						}
					}
				}
			}
		} else {
			if ($data[4] == 6) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` (`product_id`, `language_id`, `meta_keyword` ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 7) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_description` (`category_id`, `language_id`, `meta_keyword`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 8) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "manufacturer_description` (`manufacturer_id`, `language_id`, `meta_keyword`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 9) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "information_description` (`information_id`, `language_id`, `meta_keyword`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			}
		}

		return 0;
    }
	
	public function write_description($data) {
		
		switch ($data[4]) {
			case 6 : $query = "SELECT `meta_description` FROM `" . DB_PREFIX . "product_description` WHERE `product_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 7 : $query = "SELECT `meta_description` FROM `" . DB_PREFIX . "category_description` WHERE `category_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 8 : $query = "SELECT `meta_description` FROM `" . DB_PREFIX . "manufacturer_description` WHERE `manufacturer_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
			case 9 : $query = "SELECT `meta_description` FROM `" . DB_PREFIX . "information_description` WHERE `information_id` = '" . (int)$data[1] . "' AND `language_id` = '" . (int)$data[0] . "'"; break;
		}
		
		$test = $this->db->query($query);
        
		if ($test->num_rows != 0) {
			foreach ($test->rows as $value) {
				if (empty($value["meta_description"])) {
					if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_description` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 7) {
						$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_description` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 8) {
						$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_description` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					} elseif ($data[4] == 9) {
						$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_description` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
					}
				} else {
					if ($data[3] == "true") {
						if ($data[4] == 6) {
						$this->db->query("UPDATE `" . DB_PREFIX . "product_description` SET `meta_description` = '" . $data[2] . "' WHERE `product_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 7) {
							$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `meta_description` = '" . $data[2] . "' WHERE `category_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 8) {
							$this->db->query("UPDATE `" . DB_PREFIX . "manufacturer_description` SET `meta_description` = '" . $data[2] . "' WHERE `manufacturer_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						} elseif ($data[4] == 9) {
							$this->db->query("UPDATE `" . DB_PREFIX . "information_description` SET `meta_description` = '" . $data[2] . "' WHERE `information_id` = '" . (int)$data[1]. "' AND `language_id` = '" . (int)$data[0] . "'");
						}
					}
				}
			}
		} else {
			if ($data[4] == 6) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "product_description` (`product_id`, `language_id`, `meta_description` ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 7) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_description` (`category_id`, `language_id`, `meta_description`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 8) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "manufacturer_description` (`manufacturer_id`, `language_id`, `meta_description`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			} elseif ($data[4] == 9) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "information_description` (`information_id`, `language_id`, `meta_description`  ) VALUES ('" . $data[1] . "', '" . $data[0] . "', '" . $data[2] . "')");
			}
		}

		return 0;
    }

	public function getmask($askid, $lg) {
		
		$query = "SELECT `maska` FROM `" . DB_PREFIX . "mask` WHERE `maskod` = '" . (int)$askid . "' AND `language_id` = '" . (int)$lg . "'";
		
		$result = $this->db->query($query);
		
		if ($result->num_rows != 0) {
			return $result;
		} else {
			return "lost";
		}
	}

	public function putmask($askid, $lg, $textmask) {
		
		$test = $this->db->query("SELECT `maska` FROM `" . DB_PREFIX . "mask` WHERE `maskod` = '" . (int)$askid . "' AND `language_id` = '" . (int)$lg . "'");
		
		if ($test->num_rows != 0) {
			$query = "UPDATE `" . DB_PREFIX . "mask` SET `maska` = '" . $textmask . "' WHERE `maskod` = '" . (int)$askid . "' AND `language_id` = '" . (int)$lg . "'";
		} else {
			$query = "INSERT INTO `" . DB_PREFIX . "mask` (`maskod`, `maska`, `language_id`) VALUES ('" . (int)$askid . "', '" . $textmask . "', '" . (int)$lg . "')";
		}

        $this->db->query($query);
		
		return 0;
	}
}
?>