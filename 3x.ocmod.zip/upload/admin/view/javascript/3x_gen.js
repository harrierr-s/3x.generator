$.extend({
    getUrlVars: function(){
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for(var i = 0; i < hashes.length; i++){
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    },
    getUrlVar: function(name){
        return $.getUrlVars()[name];
    }
});

$(document).ready(function(){
	
	$("form input:radio").click(function(){  //Получение маски из таблицы oc_mask базы данных
		$('#templ_mask').css("background", "#ffe6f2");
		$('#templ_mask').val("Пожалуйста, подождите ...");
		var mkod = $('input[name=group1]:checked', '#form-3x').val()+''+$('input[name=group2]:checked', '#form-3x').val();
		var lg = $('input[name=group3]:checked', '#form-3x').val();
		var user_token = $.getUrlVar('user_token');

        $.ajax({
            url: 'index.php?route=extension/module/3x_gen/getmask&user_token=' + user_token, 
            type: 'POST', 
            dataType: 'json', 
            data: {"varmask":mkod, "lg":lg},
            success: function(mask){ 
                
                if(mask){
                    $('#templ_mask').val(mask.sqlmask);
					$('#templ_mask').css("background", "#fcfcfc");
                }
            }
        }); 	
	});
	
	$("#savemask").click(function(){  // Сохранение маски в таблицу oc_mask базы данных
		$('#templ_mask').css("background", "#ffd17d");
		var user_token = $.getUrlVar('user_token');
		var mkod = $('input[name=group1]:checked', '#form-3x').val()+''+$('input[name=group2]:checked', '#form-3x').val();
		var lg = $('input[name=group3]:checked', '#form-3x').val();
		var savemask = $('#templ_mask').val();
				
		$.ajax({
            url: 'index.php?route=extension/module/3x_gen/putmask&user_token=' + user_token, 
            type: 'POST', 
            dataType: 'text',
            data: {"putmask":mkod, "lg":lg, "savemask":savemask},
            success: function(mask){ 
                
                if(mask){
                    $('#templ_mask').css("background", "#fcfcfc");
                }
            }
        }); 		
	});
	
	$("#gener").click(function(){  // Запускаем генератор
		var id_1 = $('input[name=group1]:checked', '#form-3x').val();
		var id_2 = $('input[name=group2]:checked', '#form-3x').val();
		var lg = $('input[name=group3]:checked', '#form-3x').val();
		var rewrite = $('#rewrite', '#form-3x').prop('checked');
		var savemask = $('#templ_mask').val();
		var user_token = $.getUrlVar('user_token');
		
		if(savemask.length >= 1){

			$('#gener span').css("background", "rgba(255, 51, 0, 0.5)");
			
			$.ajax({
				url: 'index.php?route=extension/module/3x_gen/generate&user_token=' + user_token, 
				type: 'POST', 
				dataType: 'json', 
				data: {"id_1":id_1, "id_2":id_2, "lg":lg, "savemask":savemask, "rewrite":rewrite},
				success: function(gen){ 
					
					if(gen){
						$('#gener span').css("background", "rgba(161, 51, 180, 0.5)");
					}
				}
			});
		}		
	});
});